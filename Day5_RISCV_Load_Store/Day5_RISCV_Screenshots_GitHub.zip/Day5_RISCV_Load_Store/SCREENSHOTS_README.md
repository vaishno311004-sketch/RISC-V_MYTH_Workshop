# Day 5 Screenshot Evidence

Upload the files inside `Screenshots/` to the matching folder in `Day5_RISCV_Load_Store/` on GitHub.

- `Screenshots/01_Final_CPU_Diagram.png`
- `Screenshots/02_Simulation_PASSED_Log.png`
- `Screenshots/03_Load_45_x15_Waveform.png`
- `Screenshots/04_Load_Writeback_Waveform.png`
- `Screenshots/05_ALU_Writeback_and_Bypass_Code.png`
- `Screenshots/06_Load_Writeback_Selection_Code.png`
- `Screenshots/07_Stage5_Load_Timing_Check.png`
- `Screenshots/08_Day5_Summary_Collage.png`

The selected pass condition verifies write-back selection, not a completed physical register-file LOAD write.
